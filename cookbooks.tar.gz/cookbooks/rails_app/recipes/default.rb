#
# Cookbook:: rails_app
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.
node.default['packages-cookbook'] = [
 'nodejs',
 'imagemagick'
]
